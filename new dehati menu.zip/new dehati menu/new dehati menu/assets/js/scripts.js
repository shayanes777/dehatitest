function showSection(id){
    const sections = document.querySelectorAll('.slider');
    sections.forEach(section => section.classList.remove('active'));
    const buttons = document.querySelectorAll('.filters button');
    buttons.forEach(btn => btn.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    event.target.classList.add('active');
    
}


function cardSection(id){
    const cardSections = document.querySelectorAll('.products');
    cardSections.forEach(section => section.classList.remove('activated'));
    const cardButtons = document.querySelectorAll('.slider div');
    cardButtons.forEach(btn => btn.classList.remove('activated'));
    document.getElementById(id).classList.add('activated');
    event.target.classList.add('activated');
}

creamBtn = document.getElementsByClassName('creambutton');
hotBtn = document.getElementsByClassName('hotbutton');
iceBtn = document.getElementsByClassName('icebutton');